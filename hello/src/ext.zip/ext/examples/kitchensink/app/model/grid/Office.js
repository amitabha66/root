Ext.define('KitchenSink.model.grid.Office', {
    extend: 'Ext.data.Model',
    fields: ['city', 'totalEmployees', 'manager']
});