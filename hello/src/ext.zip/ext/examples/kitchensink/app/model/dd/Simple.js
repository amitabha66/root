Ext.define('KitchenSink.model.dd.Simple', {
    extend: 'Ext.data.Model',
    fields: ['name', 'column1', 'column2']    
});
