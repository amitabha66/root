Ext.define('KitchenSink.model.State', {
    extend: 'Ext.data.Model',
    fields: ['abbr', 'state', 'description']
});